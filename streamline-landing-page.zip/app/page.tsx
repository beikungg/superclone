import dynamic from "next/dynamic"
import ErrorBoundary from "./components/error-boundary"

// Dynamically import components with SSR disabled for components using client-side features
const Header = dynamic(() => import("./components/Header"), { ssr: true })
const Hero = dynamic(() => import("./components/Hero"), { ssr: true })
const Features = dynamic(() => import("./components/Features"), { ssr: true })
const Testimonials = dynamic(() => import("./components/Testimonials"), { ssr: true })
const Pricing = dynamic(() => import("./components/Pricing"), { ssr: true })
const CTA = dynamic(() => import("./components/CTA"), { ssr: true })
const Footer = dynamic(() => import("./components/Footer"), { ssr: true })

export default function Home() {
  return (
    <div className="flex flex-col min-h-screen">
      <ErrorBoundary>
        <Header />
        <main>
          <Hero />
          <Features />
          <Testimonials />
          <Pricing />
          <CTA />
        </main>
        <Footer />
      </ErrorBoundary>
    </div>
  )
}

